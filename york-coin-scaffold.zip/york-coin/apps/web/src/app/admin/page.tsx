'use client';

// Placeholder admin page — in the real build this lists AdminApproval rows
// with status=PENDING and lets an admin vote APPROVE / REJECT /
// REQUEST_REVISION, calling POST /admin/vote on the API.

export default function AdminPage() {
  return (
    <main>
      <h1>Admin — Pending Approvals</h1>
      <p>
        This page will list pending unanimous-consent actions (store additions, cap raises, rule
        changes, competitions, and grants over $100) and let each admin vote.
      </p>
    </main>
  );
}
