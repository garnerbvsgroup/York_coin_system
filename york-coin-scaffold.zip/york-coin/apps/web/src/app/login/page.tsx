'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { api, setToken } from '../../lib/api';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      const result = mode === 'login' ? await api.login(email, password) : await api.register(email, password);
      setToken(result.accessToken);
      router.push('/');
    } catch (err: any) {
      setError(err.message);
    }
  }

  return (
    <main>
      <h1>York Coin — {mode === 'login' ? 'Log In' : 'Register'}</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <div>
          <input type="email" placeholder="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div style={{ marginTop: 8 }}>
          <input
            type="password"
            placeholder="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" style={{ marginTop: 8 }}>
          {mode === 'login' ? 'Log In' : 'Register'}
        </button>
      </form>
      <button onClick={() => setMode(mode === 'login' ? 'register' : 'login')} style={{ marginTop: 16 }}>
        Switch to {mode === 'login' ? 'Register' : 'Log In'}
      </button>
    </main>
  );
}
