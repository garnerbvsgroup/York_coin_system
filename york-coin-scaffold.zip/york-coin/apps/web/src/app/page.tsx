'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { api, clearToken } from '../lib/api';

export default function DashboardPage() {
  const router = useRouter();
  const [balance, setBalance] = useState<string | null>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [buyAmount, setBuyAmount] = useState('100');
  const [error, setError] = useState<string | null>(null);

  async function refresh() {
    try {
      const wallet = await api.getMyWallet();
      setBalance(wallet.balance);
      setHistory(await api.getMyHistory());
      setError(null);
    } catch (e: any) {
      // Not logged in / expired token — send to login.
      router.push('/login');
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleBuy() {
    try {
      await api.buy(buyAmount);
      refresh();
    } catch (e: any) {
      setError(e.message);
    }
  }

  function handleLogout() {
    clearToken();
    router.push('/login');
  }

  return (
    <main>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>York Coin</h1>
        <button onClick={handleLogout}>Log out</button>
      </div>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <section style={{ marginTop: 24 }}>
        <h2>Balance</h2>
        <p style={{ fontSize: 32 }}>{balance ?? '—'} YC</p>
      </section>

      <section style={{ marginTop: 24 }}>
        <h2>Buy Coins</h2>
        <input value={buyAmount} onChange={(e) => setBuyAmount(e.target.value)} />
        <button onClick={handleBuy} style={{ marginLeft: 8 }}>
          Buy
        </button>
      </section>

      <section style={{ marginTop: 24 }}>
        <h2>Recent Activity</h2>
        <ul>
          {history.map((t) => (
            <li key={t.id}>
              {t.type} — {t.ycAmount} YC ({new Date(t.createdAt).toLocaleString()})
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
